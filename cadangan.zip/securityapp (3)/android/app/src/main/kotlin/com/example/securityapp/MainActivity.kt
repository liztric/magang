package com.example.securityapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
